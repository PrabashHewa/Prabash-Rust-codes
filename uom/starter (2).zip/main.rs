fn main() {
    let cow = "🐮";
    println!(cow, "says moo!");
}
